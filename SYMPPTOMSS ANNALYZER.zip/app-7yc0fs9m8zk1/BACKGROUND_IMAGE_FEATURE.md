# Medical Background Image Feature

## Overview
The Symptom Checker now features a subtle medical-themed background image that enhances the professional healthcare aesthetic while maintaining excellent readability. The same image adapts seamlessly to both light and dark modes through intelligent CSS filtering.

## Key Features

### 1. Adaptive Background Image
- **Single Image**: Uses one high-quality medical background photo
- **Dual Mode Support**: Automatically adapts to light and dark themes
- **Seamless Transition**: Smooth color changes when switching themes
- **Professional Aesthetic**: Enhances medical credibility and trust

### 2. Light Mode Styling
- **Opacity**: 8% opacity for subtle presence
- **Brightness**: Enhanced brightness (1.2x) for a clean, fresh look
- **Contrast**: Slightly reduced contrast (0.9x) for softness
- **Effect**: Creates a light, airy medical environment
- **Readability**: Maintains perfect text legibility

### 3. Dark Mode Styling
- **Opacity**: 5% opacity for even more subtlety
- **Brightness**: Reduced brightness (0.6x) for dark theme harmony
- **Contrast**: Enhanced contrast (1.1x) for definition
- **Grayscale**: 30% grayscale tint for muted appearance
- **Effect**: Creates a comfortable, low-light medical environment
- **Readability**: Ensures excellent text visibility in dark mode

### 4. Technical Implementation

#### CSS Pseudo-Element Approach
```css
body::before {
  content: '';
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-image: url('...');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  opacity: 0.08;
  z-index: 0;
  pointer-events: none;
  filter: brightness(1.2) contrast(0.9);
  transition: opacity 0.5s ease-in-out, filter 0.5s ease-in-out;
}
```

#### Dark Mode Override
```css
.dark body::before {
  opacity: 0.05;
  filter: brightness(0.6) contrast(1.1) grayscale(0.3);
}
```

### 5. Smooth Transitions

- **Opacity Transition**: 0.5 second smooth fade when switching themes
- **Filter Transition**: 0.5 second smooth color adjustment
- **Easing Function**: ease-in-out for natural, comfortable animation
- **Theme Switch**: Seamless visual transition between light and dark modes
- **No Jarring Changes**: Professional, polished appearance
- **Enhanced Comfort**: Reduces visual strain during theme changes

### 6. Performance Optimizations

- **Fixed Positioning**: Background stays in place during scrolling
- **Pointer Events Disabled**: Doesn't interfere with user interactions
- **Z-Index Management**: Properly layered behind all content
- **Single Image Load**: No duplicate images for different themes
- **CSS Filters**: Hardware-accelerated transformations
- **Efficient Transitions**: GPU-accelerated opacity and filter changes

### 7. Design Benefits

#### Visual Hierarchy
- Background adds depth without competing with content
- Subtle presence reinforces medical theme
- Maintains focus on important information

#### Brand Consistency
- Reinforces healthcare and medical professionalism
- Complements the blue and green color scheme
- Creates a cohesive visual experience

#### User Experience
- Adds visual interest without distraction
- Reduces harsh white backgrounds in light mode
- Softens dark backgrounds in dark mode
- Creates a more inviting interface

## Color Adaptation Strategy

### Light Mode Filters
1. **Brightness (1.2)**: Makes the image lighter and more vibrant
2. **Contrast (0.9)**: Softens harsh edges for a gentle appearance
3. **Opacity (0.08)**: Keeps it very subtle and non-intrusive

### Dark Mode Filters
1. **Brightness (0.6)**: Darkens the image to match dark theme
2. **Contrast (1.1)**: Adds definition in low-light conditions
3. **Grayscale (0.3)**: Removes some color for a muted look
4. **Opacity (0.05)**: Even more subtle for dark environments

## Accessibility Considerations

### Readability
- ✅ Low opacity ensures text remains highly readable
- ✅ Sufficient contrast ratios maintained in both modes
- ✅ No interference with interactive elements
- ✅ Background doesn't create visual noise

### Performance
- ✅ Single image load (no theme-specific images)
- ✅ CSS filters are hardware-accelerated
- ✅ Fixed positioning reduces repaints
- ✅ Minimal impact on page load time

### User Control
- ✅ Users can switch themes freely
- ✅ Background adapts instantly to theme changes
- ✅ No flash or jarring transitions
- ✅ Consistent experience across theme switches

## Browser Compatibility

### Supported Features
- ✅ CSS Pseudo-elements (::before)
- ✅ CSS Filters (brightness, contrast, grayscale)
- ✅ Fixed positioning
- ✅ Background-attachment: fixed

### Browser Support
- ✅ Chrome/Edge 88+ (full support)
- ✅ Firefox 85+ (full support)
- ✅ Safari 14+ (full support)
- ✅ Mobile browsers (iOS Safari 14+, Chrome Mobile 88+)

## Implementation Details

### Image Source
- **URL**: https://miaoda-site-img.s3cdn.medo.dev/images/85b96817-405f-4f98-ae6e-d059091bf4d3.jpg
- **Hosted on**: CDN for fast loading
- **Format**: JPEG for optimal compression
- **Quality**: High-resolution professional doctor photograph
- **Content**: Healthcare professional/doctor imagery with medical theme

### CSS Architecture
- **Layer**: @layer base for proper cascade
- **Specificity**: Body pseudo-element for global application
- **Inheritance**: Content elements positioned relatively (z-index: 1)
- **Isolation**: pointer-events: none prevents interaction issues

### Theme Integration
- **Light Mode**: Default styling in body::before
- **Dark Mode**: Override with .dark body::before
- **Transition**: Automatic when dark class is toggled
- **Persistence**: Works with localStorage theme preference

## Visual Impact

### Before (No Background)
- Plain solid color backgrounds
- Stark white in light mode
- Pure dark in dark mode
- Less visual depth

### After (With Background)
- Subtle medical imagery
- Enhanced professional appearance
- Softer, more inviting interface
- Added visual depth and interest

## User Feedback Considerations

### Positive Aspects
- Enhances medical credibility
- Creates professional atmosphere
- Adds visual interest
- Maintains excellent readability

### Potential Concerns
- Some users prefer minimal backgrounds
- May increase perceived complexity
- Could affect users with visual sensitivities

### Mitigation
- Very low opacity (5-8%)
- Can be easily removed if needed
- Doesn't interfere with functionality
- Maintains accessibility standards

## Future Enhancements

- Add user preference to disable background
- Implement multiple background options
- Add subtle parallax effect on scroll
- Create seasonal or themed variations
- Add animation on theme switch
- Implement lazy loading for performance
- Add blur effect option
- Create custom backgrounds for different sections

## Maintenance Notes

### Updating the Image
To change the background image:
1. Replace the URL in src/index.css
2. Adjust opacity values if needed
3. Fine-tune filter values for optimal appearance
4. Test in both light and dark modes
5. Verify readability across all components

### Removing the Feature
To remove the background:
1. Delete the body::before rule
2. Delete the .dark body::before rule
3. Remove body > * z-index rule
4. Keep body position: relative for other features

## Testing Checklist

- ✅ Image loads correctly in both modes
- ✅ Opacity is appropriate for readability
- ✅ Filters create desired visual effect
- ✅ No performance impact on scrolling
- ✅ Theme switching works smoothly
- ✅ No interference with interactive elements
- ✅ Accessible to users with visual impairments
- ✅ Works on mobile devices
- ✅ Compatible with all major browsers
