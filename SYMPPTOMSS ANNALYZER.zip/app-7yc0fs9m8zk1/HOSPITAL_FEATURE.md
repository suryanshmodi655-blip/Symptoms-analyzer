# Hospital Finder Feature

## Overview
The Symptom Checker now includes an integrated hospital finder that displays nearby medical facilities in RR Nagar, Bangalore, sorted by their Google ratings in descending order.

## Key Features

### 1. Location-Based Search
- **Base Location**: RR Nagar, Bangalore (12.9219°N, 77.5204°E)
- **Coverage**: 15 hospitals and clinics within 25 km radius
- **Distance Display**: Shows distance from RR Nagar for each facility

### 2. Rating-Based Sorting
Hospitals are automatically sorted by:
- **Primary**: Star rating (highest first)
- **Secondary**: Number of reviews (for ties)

Top-rated facilities appear first, making it easy for users to find the best medical care.

### 3. Google Maps Integration

#### View on Google Maps
- Opens the hospital location directly in Google Maps
- Works on both desktop and mobile devices
- Shows the exact location with all Google Maps features

#### Get Directions
- Provides turn-by-turn directions from RR Nagar to the hospital
- Uses Google Maps Directions API
- Automatically opens in:
  - Google Maps app (on mobile)
  - Google Maps website (on desktop)

### 4. Comprehensive Hospital Information

Each hospital card displays:
- **Rank**: Position based on rating (#1, #2, etc.)
- **Name**: Full hospital/clinic name
- **Type**: Hospital or Clinic badge
- **Rating**: Star rating with visual indicator
- **Reviews**: Total number of reviews
- **Status**: Open/Closed indicator
- **Address**: Complete address
- **Distance**: Distance from RR Nagar
- **Phone**: Clickable phone number for direct calling
- **Actions**: View on Maps and Get Directions buttons

### 5. Visual Design
- Clean card-based layout
- Color-coded badges for quick identification
- Hover effects for interactivity
- Responsive design for all screen sizes
- Consistent with medical theme (blue and green)

## Hospital Database

### Included Facilities (Sorted by Rating)

1. **Cloudnine Hospital** - 4.6★ (1,650 reviews)
   - Jayanagar, 10.5 km

2. **Manipal Hospital** - 4.5★ (2,850 reviews)
   - Malleshwaram West, 8.5 km

3. **Sakra World Hospital** - 4.5★ (1,580 reviews)
   - Marathahalli, 18.5 km

4. **Columbia Asia Hospital** - 4.4★ (1,920 reviews)
   - Hebbal, 12.3 km

5. **Narayana Health City** - 4.4★ (4,250 reviews)
   - Bommasandra, 22.1 km

6. **Aster CMI Hospital** - 4.4★ (2,180 reviews)
   - Hebbal, 13.7 km

7. **Fortis Hospital** - 4.3★ (3,120 reviews)
   - Bannerghatta Road, 15.2 km

8. **BGS Gleneagles Global Hospital** - 4.3★ (1,890 reviews)
   - Kengeri, 5.8 km

9. **Motherhood Hospital** - 4.3★ (1,120 reviews)
   - Banashankari, 7.5 km

10. **Apollo Hospital** - 4.2★ (2,640 reviews)
    - Bannerghatta Road, 14.8 km

11. **Sagar Hospital** - 4.2★ (2,340 reviews)
    - Banashankari, 7.2 km

12. **Kauvery Hospital** - 4.2★ (890 reviews)
    - Electronic City, 20.8 km

13. **Sparsh Hospital** - 4.1★ (980 reviews)
    - Rajarajeshwari Nagar, 3.2 km

14. **Vydehi Institute of Medical Sciences** - 4.0★ (1,420 reviews)
    - Whitefield, 25.3 km

15. **Rajarajeshwari Medical College Hospital** - 3.9★ (1,560 reviews)
    - Kambipura, 4.5 km

## Technical Implementation

### Data Structure
```typescript
interface Hospital {
  id: string;
  name: string;
  address: string;
  rating: number;
  totalRatings: number;
  type: 'hospital' | 'clinic';
  phone?: string;
  distance?: string;
  openNow?: boolean;
  lat: number;
  lng: number;
}
```

### Sorting Algorithm
```typescript
function getHospitalsSortedByRating(): Hospital[] {
  return [...hospitals].sort((a, b) => {
    if (b.rating !== a.rating) {
      return b.rating - a.rating;  // Sort by rating (descending)
    }
    return b.totalRatings - a.totalRatings;  // Then by review count
  });
}
```

### Google Maps URLs
- **Location View**: `https://www.google.com/maps/search/?api=1&query=[hospital name + address]`
- **Directions**: `https://www.google.com/maps/dir/?api=1&origin=[RR Nagar coords]&destination=[hospital coords]`

## User Benefits

1. **Quick Access**: Find nearby hospitals instantly without leaving the app
2. **Quality Assurance**: See ratings and reviews to choose the best facility
3. **Easy Navigation**: One-click directions to any hospital
4. **Complete Information**: All essential details in one place
5. **Mobile-Friendly**: Works seamlessly on all devices
6. **Time-Saving**: No need to search separately for hospitals

## Usage Scenarios

### Scenario 1: Emergency Situation
1. User checks symptoms and identifies a serious condition
2. Scrolls down to see nearby hospitals
3. Sees highest-rated hospitals first
4. Clicks "Get Directions" to nearest top-rated hospital
5. Google Maps opens with turn-by-turn directions

### Scenario 2: Routine Checkup
1. User identifies a mild condition
2. Reviews hospital options sorted by rating
3. Checks distance and reviews
4. Calls hospital to book appointment
5. Saves location for future visit

### Scenario 3: Comparing Options
1. User wants to compare multiple hospitals
2. Reviews ratings, distances, and review counts
3. Views each hospital on Google Maps to check surroundings
4. Makes informed decision based on comprehensive data

## Future Enhancements

- Real-time availability status
- Appointment booking integration
- Emergency services indicator
- Specialty filters (cardiology, pediatrics, etc.)
- User reviews and ratings
- Insurance acceptance information
- Average wait times
- Ambulance service integration
- 24/7 emergency contact numbers
