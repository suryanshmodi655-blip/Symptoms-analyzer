# Symptom Checker - Project Summary

## Overview
A professional medical symptom checker tool that helps users identify possible conditions based on their symptoms. The application features a clean, medical-themed interface with comprehensive disease information and integrated Google Maps functionality to find nearby hospitals and clinics.

## Key Features

### 1. Intelligent Symptom Search
- Real-time search with auto-suggestions
- Support for multiple symptoms (comma or semicolon separated)
- Smart matching algorithm that finds partial matches
- Clear search interface with easy-to-use controls

### 2. Comprehensive Disease Database
- 20 common medical conditions
- Each disease includes:
  - Primary symptoms
  - Additional symptoms to watch for
  - Typical disease duration
  - Detailed treatment recommendations
  - Severity classification (mild, moderate, severe)

### 3. Smart Matching System
- Calculates match percentage based on entered symptoms
- Sorts results by relevance (highest match first)
- Shows which symptoms matched for each disease
- Provides clear visual indicators of match quality

### 4. Nearby Hospitals & Clinics (NEW)
- **Location-based**: Centered around RR Nagar, Bangalore
- **15 hospitals and clinics** with complete information
- **Sorted by rating**: Highest-rated facilities appear first
- **Google Maps integration**:
  - View any hospital on Google Maps
  - Get directions from RR Nagar to the hospital
  - One-click navigation
- **Detailed information** for each facility:
  - Hospital/clinic name and type
  - Star rating and number of reviews
  - Complete address
  - Distance from RR Nagar
  - Phone number (clickable for direct calling)
  - Open/closed status
- **Interactive cards** with hover effects and smooth transitions

### 5. Professional Medical Design
- Medical blue (#4A90E2) primary color for trust
- Soft green (#7ED321) secondary color for health
- Clean, card-based layout
- Responsive design for all screen sizes
- **Medical background image**
  - Professional doctor photograph as subtle background
  - Adapts to both light and dark modes
  - Light mode: Brighter with enhanced contrast
  - Dark mode: Darker with grayscale tint
  - Fixed position with smooth scrolling
  - Low opacity to maintain readability
- **Dark mode support with toggle button**
  - Fixed position toggle button (top-right corner)
  - Smooth theme transitions
  - Persists user preference in localStorage
  - Respects system color scheme preference
  - Moon icon for light mode, Sun icon for dark mode

### 6. User Safety
- Prominent medical disclaimer
- Clear guidance to consult healthcare professionals
- Informative but not prescriptive language

## Technical Architecture

### Frontend Stack
- React 18 with TypeScript
- Tailwind CSS for styling
- shadcn/ui component library
- Lucide React for icons
- React Router for navigation

### Project Structure
```
src/
├── components/
│   ├── common/
│   │   └── ThemeToggle.tsx      # Dark mode toggle button
│   ├── symptom/
│   │   ├── DiseaseCard.tsx       # Disease result card component
│   │   ├── SearchBar.tsx         # Search input with suggestions
│   │   └── DisclaimerBanner.tsx  # Medical disclaimer alert
│   ├── hospital/
│   │   ├── HospitalCard.tsx      # Hospital/clinic card component
│   │   └── NearbyHospitals.tsx   # Hospitals list container
│   └── ui/                       # shadcn/ui components
├── data/
│   ├── diseases.ts               # Disease database (20 conditions)
│   └── hospitals.ts              # Hospital database (15 facilities)
├── pages/
│   └── SymptomChecker.tsx        # Main application page
├── types/
│   ├── disease.ts                # Disease TypeScript interfaces
│   └── hospital.ts               # Hospital TypeScript interfaces
├── utils/
│   └── symptomMatcher.ts         # Search and matching logic
└── routes.tsx                    # Application routing
```

### Design System
- Custom color palette optimized for medical applications
- Semantic color tokens for consistency
- Responsive typography
- Smooth transitions and hover effects
- Accessible contrast ratios

## Disease Coverage
The application includes information for:
1. Common Cold
2. Influenza (Flu)
3. Migraine
4. Gastroenteritis (Stomach Flu)
5. Allergic Rhinitis (Hay Fever)
6. Bronchitis
7. Sinusitis
8. Tension Headache
9. Urinary Tract Infection (UTI)
10. Strep Throat
11. Asthma Attack
12. Food Poisoning
13. Conjunctivitis (Pink Eye)
14. Pneumonia
15. Anxiety Disorder
16. Dehydration
17. Eczema (Atopic Dermatitis)
18. Vertigo
19. Acid Reflux (GERD)
20. Insomnia

## User Experience Flow
1. User lands on the main page with clear instructions
2. User enters symptoms in the search bar
3. Auto-suggestions appear as they type
4. User submits search
5. Results appear sorted by match percentage
6. Each result card shows:
   - Disease name and match percentage
   - Severity level
   - Additional symptoms to watch for
   - Expected duration
   - Treatment recommendations
   - Which symptoms matched their search
7. User scrolls down to see nearby hospitals and clinics
8. Hospitals are displayed sorted by rating (highest first)
9. User can:
   - View any hospital on Google Maps
   - Get directions from RR Nagar to the hospital
   - Call the hospital directly (on mobile devices)

## Google Maps Integration
- **View on Google Maps**: Opens the hospital location in Google Maps
- **Get Directions**: Opens Google Maps with directions from RR Nagar to the selected hospital
- **One-click access**: No need to manually search for hospitals
- **Mobile-friendly**: Works seamlessly on mobile devices with Google Maps app integration

## Hospital Database
The application includes 15 hospitals and clinics near RR Nagar, Bangalore:
1. Cloudnine Hospital (4.6★) - Jayanagar
2. Manipal Hospital (4.5★) - Malleshwaram West
3. Sakra World Hospital (4.5★) - Marathahalli
4. Columbia Asia Hospital (4.4★) - Hebbal
5. Narayana Health City (4.4★) - Bommasandra
6. Aster CMI Hospital (4.4★) - Hebbal
7. Fortis Hospital (4.3★) - Bannerghatta Road
8. BGS Gleneagles Global Hospital (4.3★) - Kengeri
9. Motherhood Hospital (4.3★) - Banashankari
10. Apollo Hospital (4.2★) - Bannerghatta Road
11. Sagar Hospital (4.2★) - Banashankari
12. Kauvery Hospital (4.2★) - Electronic City
13. Sparsh Hospital (4.1★) - Rajarajeshwari Nagar
14. Vydehi Institute (4.0★) - Whitefield
15. Rajarajeshwari Medical College (3.9★) - Kambipura

## Responsive Design
- Desktop-first approach with mobile adaptation
- Optimized for screens from 375px to 1920px
- Touch-friendly interface on mobile
- Readable typography at all sizes
- Proper spacing and layout on all devices

## Accessibility
- Semantic HTML structure
- ARIA labels where appropriate
- Keyboard navigation support
- High contrast color combinations
- Clear visual hierarchy

## Performance
- No external API calls (static data)
- Fast search and filtering
- Optimized component rendering
- Minimal bundle size
- Instant results display

## Future Enhancement Possibilities
- Add more diseases to the database
- Implement severity-based filtering
- Add symptom categories (respiratory, digestive, etc.)
- Include visual diagrams or illustrations
- Add multi-language support
- Integrate with real-time Google Places API for live hospital data
- Add user history tracking (with privacy considerations)
- Implement symptom severity levels
- Add age and gender-specific recommendations
- Include emergency contact numbers
- Add telemedicine consultation options
- Implement hospital availability and wait time information
- Add pharmacy locations
- Include ambulance service integration

## Development Notes
- All code passes linting with no errors
- TypeScript for type safety
- Modular component architecture
- Clean separation of concerns
- Reusable utility functions
- Comprehensive type definitions
