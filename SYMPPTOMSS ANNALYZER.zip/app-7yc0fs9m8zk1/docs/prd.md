# Symptom Checker Tool Requirements Document

## 1. Tool Name
Symptom Checker

## 2. Tool Description
An online diagnostic assistance tool that helps users identify possible diseases based on their symptoms, providing additional symptom information, disease duration, and treatment recommendations. The tool also displays nearby clinics and hospitals in RR Nagar, Bangalore, ranked by rating.

## 3. Core Features
\n### 3.1 Symptom Selection
- Display a collection of symptom buttons organized by body system or category (e.g., General, Respiratory, Digestive, Neurological)\n- Each symptom is represented as a clickable button with an icon and label (e.g., 'Headache', 'Fever', 'Cough')
- Users can select multiple symptoms by clicking the buttons
- Selected buttons change appearance (highlighted background color or border) to indicate active state
- Include a 'Clear All' button to deselect all symptoms at once
- Provide a search filter above the buttons to quickly find specific symptoms
- Display selected symptoms count indicator (e.g., '3 symptoms selected')

### 3.2 Disease Matching\n- Based on selected symptoms, display a list of possible diseases
- Show disease names with relevance ranking (most likely diseases appear first)
- Display match percentage or confidence level for each disease
\n### 3.3 Disease Information Display
For each matched disease, show:
- **Additional Symptoms**: Other common symptoms associated with this disease that the user may not have mentioned
- **Disease Duration**: Typical time course of the disease (e.g., '3-7 days', '2-4 weeks', 'chronic condition')
- **Treatment/Cure**: Recommended treatment methods, medications, or care instructions

### 3.4 Nearby Healthcare Facilities
- Display a list of nearby clinics and hospitals in RR Nagar, Bangalore
- Use Google Maps integration to fetch facility data
- Show facilities in decreasing order of rating (highest rated first)\n- For each facility, display:\n  - Facility name
  - Address
  - Rating (e.g., 4.5 stars)
  - Distance from RR Nagar location\n  - Link to view on Google Maps
- Include an embedded map view showing facility locations with markers

### 3.5 Dark Mode Toggle
- Provide a toggle button in the top-right corner to switch between light and dark modes
- Button displays a moon icon for dark mode and sun icon for light mode
- User's mode preference is saved and persists across sessions\n- Smooth transition animation when switching modes

### 3.6 Results Presentation
- Display results in an organized, easy-to-read format
- Use expandable cards or sections for each disease
- Include a disclaimer that this tool is for informational purposes only and users should consult healthcare professionals for proper diagnosis

## 4. Design Style

### Background Image
- Use a doctor-related background photo throughout the website
- The same photo appears in both light and dark modes with color adjustments:
  - **Light Mode**: Original photo with slight brightness increase and reduced opacity (around 10-15%) to maintain readability
  - **Dark Mode**: Same photo with color inversion or dark overlay filter, reduced opacity (around 8-12%) to ensure content visibility
- Background image should be subtle and not interfere with text readability
- Apply a slight blur effect to keep focus on foreground content

### Color Scheme
**Light Mode:**
- Primary color: Clean medical blue (#4A90E2) for trust and professionalism
- Secondary color: Soft green (#7ED321) for positive health associations
- Background: Light gray (#F5F7FA) layered over the doctor background photo\n- Text: Dark gray (#333333) for clear readability

**Dark Mode:**
- Primary color: Bright blue (#5BA3FF) for visibility on dark backgrounds
- Secondary color: Muted green (#8FD14F) for reduced eye strain\n- Background: Dark navy (#1A1D29) layered over the color-adjusted doctor background photo\n- Text: Light gray (#E5E5E5) for clear contrast
- Card backgrounds: Slightly lighter dark gray (#252836) with subtle transparency

### Visual Details
- Rounded corners (8px radius) for a friendly, approachable feel
- Subtle shadows on cards for depth and hierarchy
- Clean, sans-serif font (e.g., Inter, Roboto) for medical clarity
- Icon-based visual indicators for symptoms, duration, treatment sections, and location markers
- Smooth color transitions (0.3s) when switching between light and dark modes\n- Background image transitions smoothly with color filter changes
- Symptom buttons have rounded corners (6px radius) with hover effects and smooth selection animations

### Layout\n- Card-based layout for disease results and healthcare facilities
- Symptom selection panel at the top with organized button grid layout
- Dark mode toggle button positioned in the top-right corner
- Vertical scrolling list of results with clear spacing between items
- Embedded map section below disease results showing nearby facilities
- Responsive design that adapts to mobile and desktop screens
- Content cards have semi-transparent backgrounds to allow subtle background image visibility while maintaining readability