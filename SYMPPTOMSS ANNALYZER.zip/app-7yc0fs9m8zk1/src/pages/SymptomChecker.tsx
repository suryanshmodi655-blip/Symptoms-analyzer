import { useState } from 'react';
import { SearchBar } from '@/components/symptom/SearchBar';
import { DiseaseCard } from '@/components/symptom/DiseaseCard';
import { DisclaimerBanner } from '@/components/symptom/DisclaimerBanner';
import { NearbyHospitals } from '@/components/hospital/NearbyHospitals';
import { ThemeToggle } from '@/components/common/ThemeToggle';
import { searchDiseases } from '@/utils/symptomMatcher';
import type { SearchResult } from '@/types/disease';
import { Stethoscope, FileSearch } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function SymptomChecker() {
  const [searchQuery, setSearchQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [hasSearched, setHasSearched] = useState(false);

  const handleSearch = (query: string) => {
    const searchResults = searchDiseases(query);
    setResults(searchResults);
    setHasSearched(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <ThemeToggle />
      <div className="container mx-auto px-4 py-8 xl:py-12">
        <div className="max-w-6xl mx-auto space-y-8">
          <div className="text-center space-y-4">
            <div className="flex justify-center">
              <div className="p-4 bg-primary/10 rounded-full">
                <Stethoscope className="w-12 h-12 xl:w-16 xl:h-16 text-primary" />
              </div>
            </div>
            <h1 className="text-3xl xl:text-5xl font-bold text-foreground">Symptom Checker</h1>
            <p className="text-base xl:text-lg text-muted-foreground max-w-2xl mx-auto">
              Enter your symptoms to discover possible conditions and get helpful information about
              treatment options. Separate multiple symptoms with commas.
            </p>
          </div>

          <SearchBar
            onSearch={handleSearch}
            value={searchQuery}
            onChange={setSearchQuery}
          />

          <DisclaimerBanner />

          {hasSearched && (
            <div className="space-y-6">
              {results.length > 0 ? (
                <>
                  <div className="flex items-center justify-between">
                    <h2 className="text-xl xl:text-2xl font-semibold text-foreground">
                      Possible Conditions ({results.length})
                    </h2>
                    <p className="text-sm text-muted-foreground">
                      Sorted by relevance
                    </p>
                  </div>
                  <div className="grid gap-6">
                    {results.map((disease) => (
                      <DiseaseCard key={disease.id} disease={disease} />
                    ))}
                  </div>
                </>
              ) : (
                <div className="text-center py-12 space-y-4">
                  <div className="flex justify-center">
                    <div className="p-4 bg-muted rounded-full">
                      <FileSearch className="w-12 h-12 text-muted-foreground" />
                    </div>
                  </div>
                  <h3 className="text-xl font-semibold text-foreground">
                    No Matches Found
                  </h3>
                  <p className="text-muted-foreground max-w-md mx-auto">
                    We couldn't find any conditions matching your symptoms. Try different keywords
                    or consult a healthcare professional for personalized advice.
                  </p>
                </div>
              )}
            </div>
          )}

          {!hasSearched && (
            <div className="text-center py-12 space-y-4">
              <div className="flex justify-center">
                <div className="p-4 bg-muted rounded-full">
                  <FileSearch className="w-12 h-12 text-muted-foreground" />
                </div>
              </div>
              <h3 className="text-xl font-semibold text-foreground">
                Start Your Search
              </h3>
              <p className="text-muted-foreground max-w-md mx-auto">
                Enter your symptoms in the search bar above to get started. You can enter multiple
                symptoms separated by commas for more accurate results.
              </p>
            </div>
          )}

          <Separator className="my-12" />

          <NearbyHospitals />
        </div>
      </div>
    </div>
  );
}
