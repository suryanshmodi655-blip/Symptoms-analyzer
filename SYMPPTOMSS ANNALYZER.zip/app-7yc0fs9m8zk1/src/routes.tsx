import SymptomChecker from './pages/SymptomChecker';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Symptom Checker',
    path: '/',
    element: <SymptomChecker />
  }
];

export default routes;
