import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import routes from './routes';

/**
 * Root application component.
 * Uses React Router to render the pages defined in src/routes.tsx.
 */
const App: React.FC = () => {
  return (
    <Router>
      <div className="min-h-screen bg-background text-foreground">
        <main className="flex-1">
          <Routes>
            {routes.map((route, index) => (
              <Route
                key={index}
                path={route.path}
                element={route.element}
              />
            ))}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
};

export default App;
