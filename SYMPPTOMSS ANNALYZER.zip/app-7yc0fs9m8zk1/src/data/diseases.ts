import type { Disease } from '@/types/disease';

export const diseases: Disease[] = [
  {
    id: '1',
    name: 'Common Cold',
    symptoms: ['runny nose', 'sneezing', 'sore throat', 'cough', 'congestion'],
    additionalSymptoms: ['mild headache', 'fatigue', 'watery eyes', 'mild body aches'],
    duration: '7-10 days',
    treatment: 'Rest, stay hydrated, over-the-counter cold medications, throat lozenges. Symptoms usually resolve on their own. Consult a doctor if symptoms worsen or persist beyond 10 days.',
    severity: 'mild'
  },
  {
    id: '2',
    name: 'Influenza (Flu)',
    symptoms: ['fever', 'cough', 'sore throat', 'body aches', 'fatigue', 'headache'],
    additionalSymptoms: ['chills', 'sweating', 'nasal congestion', 'weakness', 'loss of appetite'],
    duration: '1-2 weeks',
    treatment: 'Rest, fluids, antiviral medications (if prescribed within 48 hours), fever reducers like acetaminophen or ibuprofen. Seek medical attention if symptoms are severe or if you are in a high-risk group.',
    severity: 'moderate'
  },
  {
    id: '3',
    name: 'Migraine',
    symptoms: ['severe headache', 'nausea', 'sensitivity to light', 'sensitivity to sound'],
    additionalSymptoms: ['vomiting', 'visual disturbances (aura)', 'dizziness', 'throbbing pain on one side of head'],
    duration: '4-72 hours',
    treatment: 'Rest in a dark, quiet room, pain relievers (ibuprofen, aspirin), prescription migraine medications (triptans), avoid triggers. Consult a neurologist for chronic migraines.',
    severity: 'moderate'
  },
  {
    id: '4',
    name: 'Gastroenteritis (Stomach Flu)',
    symptoms: ['diarrhea', 'nausea', 'vomiting', 'stomach cramps', 'abdominal pain'],
    additionalSymptoms: ['fever', 'headache', 'muscle aches', 'loss of appetite', 'dehydration'],
    duration: '1-3 days',
    treatment: 'Stay hydrated with clear fluids, oral rehydration solutions, bland diet (BRAT: bananas, rice, applesauce, toast), rest. Seek medical care if severe dehydration, bloody stools, or high fever occurs.',
    severity: 'moderate'
  },
  {
    id: '5',
    name: 'Allergic Rhinitis (Hay Fever)',
    symptoms: ['sneezing', 'runny nose', 'itchy eyes', 'nasal congestion'],
    additionalSymptoms: ['watery eyes', 'postnasal drip', 'cough', 'fatigue', 'itchy throat'],
    duration: 'Seasonal or year-round (chronic)',
    treatment: 'Antihistamines, nasal corticosteroid sprays, decongestants, avoid allergens, allergy shots (immunotherapy) for severe cases. Consult an allergist for persistent symptoms.',
    severity: 'mild'
  },
  {
    id: '6',
    name: 'Bronchitis',
    symptoms: ['persistent cough', 'mucus production', 'chest discomfort', 'fatigue'],
    additionalSymptoms: ['shortness of breath', 'mild fever', 'wheezing', 'sore throat'],
    duration: '2-3 weeks',
    treatment: 'Rest, fluids, cough suppressants, humidifier, avoid irritants (smoke). Antibiotics are not usually needed unless bacterial infection is confirmed. See a doctor if breathing difficulties occur.',
    severity: 'moderate'
  },
  {
    id: '7',
    name: 'Sinusitis',
    symptoms: ['facial pain', 'nasal congestion', 'thick nasal discharge', 'headache'],
    additionalSymptoms: ['reduced sense of smell', 'cough', 'fever', 'dental pain', 'fatigue'],
    duration: '7-10 days (acute), 12+ weeks (chronic)',
    treatment: 'Nasal saline irrigation, decongestants, nasal corticosteroids, pain relievers, warm compresses. Antibiotics may be prescribed for bacterial infections. Consult an ENT specialist for chronic cases.',
    severity: 'moderate'
  },
  {
    id: '8',
    name: 'Tension Headache',
    symptoms: ['dull headache', 'pressure around forehead', 'tenderness in scalp', 'neck pain'],
    additionalSymptoms: ['shoulder pain', 'mild sensitivity to light or sound', 'difficulty concentrating'],
    duration: '30 minutes to several hours',
    treatment: 'Over-the-counter pain relievers (ibuprofen, aspirin), stress management, relaxation techniques, massage, proper posture, regular exercise. Seek medical advice for frequent headaches.',
    severity: 'mild'
  },
  {
    id: '9',
    name: 'Urinary Tract Infection (UTI)',
    symptoms: ['burning sensation during urination', 'frequent urination', 'cloudy urine', 'pelvic pain'],
    additionalSymptoms: ['strong-smelling urine', 'blood in urine', 'lower abdominal discomfort', 'urgency to urinate'],
    duration: '3-5 days with treatment',
    treatment: 'Antibiotics (prescribed by doctor), drink plenty of water, cranberry juice may help, urinate frequently. Seek immediate medical attention if fever, back pain, or severe symptoms develop.',
    severity: 'moderate'
  },
  {
    id: '10',
    name: 'Strep Throat',
    symptoms: ['severe sore throat', 'pain when swallowing', 'fever', 'swollen lymph nodes'],
    additionalSymptoms: ['red and swollen tonsils', 'white patches on throat', 'headache', 'rash', 'nausea'],
    duration: '3-7 days with treatment',
    treatment: 'Antibiotics (penicillin or amoxicillin), pain relievers, throat lozenges, warm salt water gargle, rest, fluids. Complete the full course of antibiotics to prevent complications.',
    severity: 'moderate'
  },
  {
    id: '11',
    name: 'Asthma Attack',
    symptoms: ['shortness of breath', 'wheezing', 'chest tightness', 'cough'],
    additionalSymptoms: ['rapid breathing', 'difficulty speaking', 'anxiety', 'fatigue', 'bluish lips or face (severe)'],
    duration: 'Minutes to hours',
    treatment: 'Quick-relief inhaler (albuterol), stay calm, sit upright, avoid triggers. Seek emergency care if symptoms don\'t improve with medication or if severe breathing difficulty occurs.',
    severity: 'severe'
  },
  {
    id: '12',
    name: 'Food Poisoning',
    symptoms: ['nausea', 'vomiting', 'diarrhea', 'abdominal cramps'],
    additionalSymptoms: ['fever', 'weakness', 'headache', 'loss of appetite', 'dehydration'],
    duration: '1-3 days',
    treatment: 'Rest, clear fluids, oral rehydration solutions, bland diet once vomiting stops. Avoid solid foods initially. Seek medical care for severe symptoms, bloody stools, or signs of dehydration.',
    severity: 'moderate'
  },
  {
    id: '13',
    name: 'Conjunctivitis (Pink Eye)',
    symptoms: ['red eyes', 'itchy eyes', 'discharge from eyes', 'tearing'],
    additionalSymptoms: ['crusty eyelids', 'sensitivity to light', 'gritty feeling in eyes', 'swollen eyelids'],
    duration: '7-10 days',
    treatment: 'Warm compresses, artificial tears, antibiotic eye drops (for bacterial), antihistamine drops (for allergic). Avoid touching eyes, wash hands frequently. Consult an eye doctor if symptoms persist.',
    severity: 'mild'
  },
  {
    id: '14',
    name: 'Pneumonia',
    symptoms: ['cough with phlegm', 'fever', 'chest pain', 'shortness of breath', 'fatigue'],
    additionalSymptoms: ['chills', 'sweating', 'rapid breathing', 'confusion (in elderly)', 'nausea', 'vomiting'],
    duration: '2-3 weeks with treatment',
    treatment: 'Antibiotics (for bacterial), rest, fluids, fever reducers, oxygen therapy (if needed). Hospitalization may be required for severe cases. Seek immediate medical attention for breathing difficulties.',
    severity: 'severe'
  },
  {
    id: '15',
    name: 'Anxiety Disorder',
    symptoms: ['excessive worry', 'restlessness', 'difficulty concentrating', 'irritability'],
    additionalSymptoms: ['muscle tension', 'sleep disturbances', 'rapid heartbeat', 'sweating', 'trembling', 'fatigue'],
    duration: 'Chronic (ongoing)',
    treatment: 'Cognitive behavioral therapy (CBT), relaxation techniques, exercise, medication (SSRIs, benzodiazepines if prescribed), stress management. Consult a mental health professional for proper diagnosis and treatment.',
    severity: 'moderate'
  },
  {
    id: '16',
    name: 'Dehydration',
    symptoms: ['thirst', 'dry mouth', 'fatigue', 'dizziness', 'dark urine'],
    additionalSymptoms: ['decreased urination', 'dry skin', 'headache', 'rapid heartbeat', 'confusion (severe)'],
    duration: 'Hours to days',
    treatment: 'Drink water and oral rehydration solutions, rest, avoid caffeine and alcohol. Severe dehydration requires medical attention and IV fluids. Prevent by drinking adequate fluids daily.',
    severity: 'moderate'
  },
  {
    id: '17',
    name: 'Eczema (Atopic Dermatitis)',
    symptoms: ['itchy skin', 'red patches', 'dry skin', 'rash'],
    additionalSymptoms: ['thickened skin', 'small bumps', 'oozing or crusting', 'sensitive skin', 'discolored patches'],
    duration: 'Chronic (flare-ups)',
    treatment: 'Moisturizers, topical corticosteroids, avoid triggers (irritants, allergens), antihistamines for itching, cool compresses. Consult a dermatologist for severe or persistent cases.',
    severity: 'mild'
  },
  {
    id: '18',
    name: 'Vertigo',
    symptoms: ['spinning sensation', 'dizziness', 'loss of balance', 'nausea'],
    additionalSymptoms: ['vomiting', 'sweating', 'abnormal eye movements', 'headache', 'ringing in ears'],
    duration: 'Minutes to hours per episode',
    treatment: 'Vestibular rehabilitation exercises, medications (meclizine, antihistamines), avoid sudden movements, stay hydrated. Consult a doctor to determine underlying cause (BPPV, Meniere\'s disease, etc.).',
    severity: 'moderate'
  },
  {
    id: '19',
    name: 'Acid Reflux (GERD)',
    symptoms: ['heartburn', 'chest pain', 'difficulty swallowing', 'regurgitation'],
    additionalSymptoms: ['sour taste in mouth', 'chronic cough', 'hoarseness', 'feeling of lump in throat'],
    duration: 'Chronic (ongoing)',
    treatment: 'Antacids, H2 blockers, proton pump inhibitors (PPIs), lifestyle changes (avoid trigger foods, eat smaller meals, don\'t lie down after eating), elevate head while sleeping. Consult a gastroenterologist for persistent symptoms.',
    severity: 'moderate'
  },
  {
    id: '20',
    name: 'Insomnia',
    symptoms: ['difficulty falling asleep', 'difficulty staying asleep', 'waking up too early', 'daytime fatigue'],
    additionalSymptoms: ['irritability', 'difficulty concentrating', 'anxiety about sleep', 'decreased performance'],
    duration: 'Acute (days to weeks) or Chronic (3+ months)',
    treatment: 'Sleep hygiene improvements, cognitive behavioral therapy for insomnia (CBT-I), relaxation techniques, avoid caffeine and screens before bed, maintain regular sleep schedule. Consult a sleep specialist if chronic.',
    severity: 'moderate'
  }
];
