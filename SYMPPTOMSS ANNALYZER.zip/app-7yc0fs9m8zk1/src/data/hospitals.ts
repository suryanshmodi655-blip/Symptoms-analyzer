import type { Hospital } from '@/types/hospital';

export const RR_NAGAR_LOCATION = {
  lat: 12.9219,
  lng: 77.5204,
  name: 'RR Nagar, Bangalore'
};

export const hospitals: Hospital[] = [
  {
    id: '1',
    name: 'Manipal Hospital',
    address: 'Malleshwaram West, Bangalore',
    rating: 4.5,
    totalRatings: 2850,
    type: 'hospital',
    phone: '+91 80 2566 6666',
    distance: '8.5 km',
    openNow: true,
    lat: 12.9897,
    lng: 77.5702
  },
  {
    id: '2',
    name: 'Columbia Asia Hospital',
    address: 'Kirloskar Business Park, Hebbal, Bangalore',
    rating: 4.4,
    totalRatings: 1920,
    type: 'hospital',
    phone: '+91 80 6614 6614',
    distance: '12.3 km',
    openNow: true,
    lat: 13.0358,
    lng: 77.5970
  },
  {
    id: '3',
    name: 'Fortis Hospital',
    address: 'Bannerghatta Road, Bangalore',
    rating: 4.3,
    totalRatings: 3120,
    type: 'hospital',
    phone: '+91 80 6621 4444',
    distance: '15.2 km',
    openNow: true,
    lat: 12.8899,
    lng: 77.6055
  },
  {
    id: '4',
    name: 'Apollo Hospital',
    address: 'Bannerghatta Road, Bangalore',
    rating: 4.2,
    totalRatings: 2640,
    type: 'hospital',
    phone: '+91 80 2630 0100',
    distance: '14.8 km',
    openNow: true,
    lat: 12.8934,
    lng: 77.6006
  },
  {
    id: '5',
    name: 'Sakra World Hospital',
    address: 'Marathahalli, Bangalore',
    rating: 4.5,
    totalRatings: 1580,
    type: 'hospital',
    phone: '+91 80 4969 4969',
    distance: '18.5 km',
    openNow: true,
    lat: 12.9591,
    lng: 77.6974
  },
  {
    id: '6',
    name: 'Narayana Health City',
    address: 'Bommasandra, Bangalore',
    rating: 4.4,
    totalRatings: 4250,
    type: 'hospital',
    phone: '+91 80 7122 2222',
    distance: '22.1 km',
    openNow: true,
    lat: 12.8449,
    lng: 77.6826
  },
  {
    id: '7',
    name: 'BGS Gleneagles Global Hospital',
    address: 'Kengeri, Bangalore',
    rating: 4.3,
    totalRatings: 1890,
    type: 'hospital',
    phone: '+91 80 2222 2222',
    distance: '5.8 km',
    openNow: true,
    lat: 12.9141,
    lng: 77.4854
  },
  {
    id: '8',
    name: 'Sagar Hospital',
    address: 'Banashankari, Bangalore',
    rating: 4.2,
    totalRatings: 2340,
    type: 'hospital',
    phone: '+91 80 2661 1111',
    distance: '7.2 km',
    openNow: true,
    lat: 12.9250,
    lng: 77.5500
  },
  {
    id: '9',
    name: 'Cloudnine Hospital',
    address: 'Jayanagar, Bangalore',
    rating: 4.6,
    totalRatings: 1650,
    type: 'hospital',
    phone: '+91 80 4115 1500',
    distance: '10.5 km',
    openNow: true,
    lat: 12.9250,
    lng: 77.5833
  },
  {
    id: '10',
    name: 'Aster CMI Hospital',
    address: 'Hebbal, Bangalore',
    rating: 4.4,
    totalRatings: 2180,
    type: 'hospital',
    phone: '+91 80 4344 4444',
    distance: '13.7 km',
    openNow: true,
    lat: 13.0358,
    lng: 77.5970
  },
  {
    id: '11',
    name: 'Sparsh Hospital',
    address: 'Rajarajeshwari Nagar, Bangalore',
    rating: 4.1,
    totalRatings: 980,
    type: 'hospital',
    phone: '+91 80 4344 4444',
    distance: '3.2 km',
    openNow: true,
    lat: 12.9100,
    lng: 77.5100
  },
  {
    id: '12',
    name: 'Vydehi Institute of Medical Sciences',
    address: 'Whitefield, Bangalore',
    rating: 4.0,
    totalRatings: 1420,
    type: 'hospital',
    phone: '+91 80 2845 6767',
    distance: '25.3 km',
    openNow: true,
    lat: 12.9698,
    lng: 77.7499
  },
  {
    id: '13',
    name: 'Motherhood Hospital',
    address: 'Banashankari, Bangalore',
    rating: 4.3,
    totalRatings: 1120,
    type: 'hospital',
    phone: '+91 80 4897 4897',
    distance: '7.5 km',
    openNow: true,
    lat: 12.9250,
    lng: 77.5500
  },
  {
    id: '14',
    name: 'Kauvery Hospital',
    address: 'Electronic City, Bangalore',
    rating: 4.2,
    totalRatings: 890,
    type: 'hospital',
    phone: '+91 80 6801 6801',
    distance: '20.8 km',
    openNow: true,
    lat: 12.8456,
    lng: 77.6603
  },
  {
    id: '15',
    name: 'Rajarajeshwari Medical College Hospital',
    address: 'Kambipura, Bangalore',
    rating: 3.9,
    totalRatings: 1560,
    type: 'hospital',
    phone: '+91 80 2806 9999',
    distance: '4.5 km',
    openNow: true,
    lat: 12.9050,
    lng: 77.5050
  }
];

export function getHospitalsSortedByRating(): Hospital[] {
  return [...hospitals].sort((a, b) => {
    if (b.rating !== a.rating) {
      return b.rating - a.rating;
    }
    return b.totalRatings - a.totalRatings;
  });
}

export function getGoogleMapsUrl(hospital: Hospital): string {
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(hospital.name + ' ' + hospital.address)}`;
}

export function getDirectionsUrl(hospital: Hospital): string {
  return `https://www.google.com/maps/dir/?api=1&origin=${RR_NAGAR_LOCATION.lat},${RR_NAGAR_LOCATION.lng}&destination=${hospital.lat},${hospital.lng}`;
}
