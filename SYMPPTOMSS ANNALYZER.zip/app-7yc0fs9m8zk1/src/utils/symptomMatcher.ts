import type { Disease, SearchResult } from '@/types/disease';
import { diseases } from '@/data/diseases';

export function normalizeSymptom(symptom: string): string {
  return symptom.toLowerCase().trim();
}

export function parseSymptoms(input: string): string[] {
  const separators = /[,;]/;
  return input
    .split(separators)
    .map(s => normalizeSymptom(s))
    .filter(s => s.length > 0);
}

export function calculateMatch(disease: Disease, searchSymptoms: string[]): {
  percentage: number;
  matchedSymptoms: string[];
} {
  if (searchSymptoms.length === 0) {
    return { percentage: 0, matchedSymptoms: [] };
  }

  const allDiseaseSymptoms = [...disease.symptoms, ...disease.additionalSymptoms].map(normalizeSymptom);
  const matchedSymptoms: string[] = [];

  for (const searchSymptom of searchSymptoms) {
    const isMatch = allDiseaseSymptoms.some(diseaseSymptom => {
      return diseaseSymptom.includes(searchSymptom) || searchSymptom.includes(diseaseSymptom);
    });

    if (isMatch) {
      matchedSymptoms.push(searchSymptom);
    }
  }

  const percentage = Math.round((matchedSymptoms.length / searchSymptoms.length) * 100);
  return { percentage, matchedSymptoms };
}

export function searchDiseases(symptomInput: string): SearchResult[] {
  const searchSymptoms = parseSymptoms(symptomInput);

  if (searchSymptoms.length === 0) {
    return [];
  }

  const results: SearchResult[] = [];

  for (const disease of diseases) {
    const { percentage, matchedSymptoms } = calculateMatch(disease, searchSymptoms);

    if (percentage > 0) {
      results.push({
        ...disease,
        matchPercentage: percentage,
        matchedSymptoms
      });
    }
  }

  return results.sort((a, b) => b.matchPercentage - a.matchPercentage);
}

export function getAllSymptoms(): string[] {
  const symptomsSet = new Set<string>();

  for (const disease of diseases) {
    for (const symptom of [...disease.symptoms, ...disease.additionalSymptoms]) {
      symptomsSet.add(symptom);
    }
  }

  return Array.from(symptomsSet).sort();
}
