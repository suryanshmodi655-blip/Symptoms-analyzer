export interface Hospital {
  id: string;
  name: string;
  address: string;
  rating: number;
  totalRatings: number;
  type: 'hospital' | 'clinic';
  phone?: string;
  distance?: string;
  openNow?: boolean;
  lat: number;
  lng: number;
}
