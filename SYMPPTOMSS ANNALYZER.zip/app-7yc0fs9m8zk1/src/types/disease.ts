export interface Disease {
  id: string;
  name: string;
  symptoms: string[];
  additionalSymptoms: string[];
  duration: string;
  treatment: string;
  severity: 'mild' | 'moderate' | 'severe';
}

export interface SearchResult extends Disease {
  matchPercentage: number;
  matchedSymptoms: string[];
}
