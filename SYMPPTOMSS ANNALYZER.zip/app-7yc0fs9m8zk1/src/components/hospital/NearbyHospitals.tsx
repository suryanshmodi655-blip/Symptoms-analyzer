import { HospitalCard } from './HospitalCard';
import { getHospitalsSortedByRating, RR_NAGAR_LOCATION } from '@/data/hospitals';
import { MapPinned } from 'lucide-react';

export function NearbyHospitals() {
  const hospitals = getHospitalsSortedByRating();

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-primary/10 rounded-lg">
            <MapPinned className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl xl:text-3xl font-bold text-foreground">
              Nearby Hospitals & Clinics
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              Near {RR_NAGAR_LOCATION.name} • Sorted by rating
            </p>
          </div>
        </div>
        <p className="text-muted-foreground">
          Find the best-rated medical facilities near you. Click on any hospital to view on Google
          Maps or get directions.
        </p>
      </div>

      <div className="grid gap-6">
        {hospitals.map((hospital, index) => (
          <HospitalCard key={hospital.id} hospital={hospital} rank={index + 1} />
        ))}
      </div>
    </div>
  );
}
