import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MapPin, Phone, Star, Navigation, ExternalLink } from 'lucide-react';
import type { Hospital } from '@/types/hospital';
import { getGoogleMapsUrl, getDirectionsUrl } from '@/data/hospitals';

interface HospitalCardProps {
  hospital: Hospital;
  rank: number;
}

export function HospitalCard({ hospital, rank }: HospitalCardProps) {
  const handleViewOnMap = () => {
    window.open(getGoogleMapsUrl(hospital), '_blank');
  };

  const handleGetDirections = () => {
    window.open(getDirectionsUrl(hospital), '_blank');
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-300 border-border">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Badge variant="secondary" className="text-lg font-bold px-3 py-1">
                #{rank}
              </Badge>
              <CardTitle className="text-xl font-semibold text-card-foreground">
                {hospital.name}
              </CardTitle>
            </div>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex items-center gap-1 bg-accent text-accent-foreground px-3 py-1 rounded-md">
                <Star className="w-4 h-4 fill-current" />
                <span className="font-semibold">{hospital.rating}</span>
              </div>
              <span className="text-sm text-muted-foreground">
                ({hospital.totalRatings.toLocaleString()} reviews)
              </span>
              {hospital.openNow && (
                <Badge variant="outline" className="bg-accent/20 text-accent-foreground border-accent">
                  Open Now
                </Badge>
              )}
            </div>
          </div>
          <Badge className="bg-primary text-primary-foreground capitalize">
            {hospital.type}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div className="flex items-start gap-3">
            <MapPin className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
            <div className="flex-1">
              <p className="text-muted-foreground">{hospital.address}</p>
              {hospital.distance && (
                <p className="text-sm text-primary font-medium mt-1">
                  {hospital.distance} from RR Nagar
                </p>
              )}
            </div>
          </div>

          {hospital.phone && (
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-primary flex-shrink-0" />
              <a
                href={`tel:${hospital.phone}`}
                className="text-muted-foreground hover:text-primary transition-colors"
              >
                {hospital.phone}
              </a>
            </div>
          )}
        </div>

        <div className="flex flex-wrap gap-3 pt-2">
          <Button
            onClick={handleViewOnMap}
            variant="default"
            className="flex items-center gap-2"
          >
            <ExternalLink className="w-4 h-4" />
            View on Google Maps
          </Button>
          <Button
            onClick={handleGetDirections}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Navigation className="w-4 h-4" />
            Get Directions
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
