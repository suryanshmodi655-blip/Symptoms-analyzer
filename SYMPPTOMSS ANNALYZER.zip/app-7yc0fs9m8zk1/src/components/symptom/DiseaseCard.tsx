import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Activity, Clock, Pill, AlertCircle } from 'lucide-react';
import type { SearchResult } from '@/types/disease';

interface DiseaseCardProps {
  disease: SearchResult;
}

export function DiseaseCard({ disease }: DiseaseCardProps) {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'mild':
        return 'bg-accent text-accent-foreground';
      case 'moderate':
        return 'bg-warning text-warning-foreground';
      case 'severe':
        return 'bg-destructive text-destructive-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-300 border-border">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <CardTitle className="text-xl font-semibold text-card-foreground">
            {disease.name}
          </CardTitle>
          <div className="flex flex-col items-end gap-2">
            <Badge variant="default" className="bg-primary text-primary-foreground font-semibold">
              {disease.matchPercentage}% Match
            </Badge>
            <Badge className={getSeverityColor(disease.severity)}>
              {disease.severity.charAt(0).toUpperCase() + disease.severity.slice(1)}
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-primary">
            <Activity className="w-5 h-5" />
            <h3 className="font-semibold text-card-foreground">Additional Symptoms</h3>
          </div>
          <div className="flex flex-wrap gap-2">
            {disease.additionalSymptoms.map((symptom, index) => (
              <Badge key={index} variant="outline" className="text-sm">
                {symptom}
              </Badge>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2 text-primary">
            <Clock className="w-5 h-5" />
            <h3 className="font-semibold text-card-foreground">Typical Duration</h3>
          </div>
          <p className="text-muted-foreground">{disease.duration}</p>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2 text-primary">
            <Pill className="w-5 h-5" />
            <h3 className="font-semibold text-card-foreground">Treatment & Care</h3>
          </div>
          <p className="text-muted-foreground leading-relaxed">{disease.treatment}</p>
        </div>

        {disease.matchedSymptoms.length > 0 && (
          <div className="pt-2 border-t border-border">
            <div className="flex items-center gap-2 text-accent">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm font-medium text-card-foreground">
                Matched your symptoms:
              </span>
            </div>
            <div className="flex flex-wrap gap-2 mt-2">
              {disease.matchedSymptoms.map((symptom, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  {symptom}
                </Badge>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
