import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';

export function DisclaimerBanner() {
  return (
    <Alert className="border-warning bg-warning/10">
      <AlertTriangle className="h-5 w-5 text-warning" />
      <AlertTitle className="text-warning font-semibold">Medical Disclaimer</AlertTitle>
      <AlertDescription className="text-muted-foreground">
        This tool is for informational purposes only and should not be used as a substitute for
        professional medical advice, diagnosis, or treatment. Always consult with a qualified
        healthcare provider for proper medical evaluation and treatment recommendations.
      </AlertDescription>
    </Alert>
  );
}
