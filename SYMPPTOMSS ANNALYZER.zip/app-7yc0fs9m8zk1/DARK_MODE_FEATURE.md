# Dark Mode Feature

## Overview
The Symptom Checker now includes a fully functional dark mode toggle that allows users to switch between light and dark themes with a single click.

## Key Features

### 1. Toggle Button
- **Location**: Fixed position in the top-right corner of the screen
- **Design**: Circular button with shadow effects
- **Icons**: 
  - Moon icon (🌙) when in light mode - click to switch to dark
  - Sun icon (☀️) when in dark mode - click to switch to light
- **Accessibility**: Includes proper ARIA labels for screen readers

### 2. Theme Persistence
- **localStorage**: User's theme preference is saved in browser storage
- **Automatic Restoration**: Theme preference is restored on page reload
- **Cross-Session**: Theme persists across browser sessions

### 3. System Preference Detection
- **Automatic Detection**: Respects user's system color scheme preference
- **First Visit**: If no saved preference exists, uses system preference
- **Fallback**: Defaults to light mode if no system preference is set

### 4. Smooth Transitions
- **Instant Switching**: Theme changes immediately on click
- **No Flash**: Proper initialization prevents theme flashing on load
- **Consistent**: All components respect the theme setting

## Technical Implementation

### Component Structure
```typescript
// ThemeToggle.tsx
- Uses React hooks (useState, useEffect)
- Manages theme state locally
- Syncs with localStorage
- Toggles 'dark' class on document root
```

### Theme Detection Logic
```typescript
1. Check localStorage for saved theme
2. If no saved theme, check system preference
3. Apply theme to document.documentElement
4. Update component state
```

### Theme Toggle Logic
```typescript
1. User clicks button
2. Toggle theme state (light ↔ dark)
3. Save new theme to localStorage
4. Update document.documentElement class
5. Icon updates automatically via state
```

## User Experience

### Light Mode
- Clean, bright interface
- Medical blue and green colors
- White backgrounds
- Dark text for readability
- Moon icon visible in toggle button

### Dark Mode
- Comfortable dark interface
- Reduced eye strain in low-light conditions
- Inverted color scheme
- Light text on dark backgrounds
- Sun icon visible in toggle button

## Benefits

1. **Eye Comfort**: Reduces eye strain in low-light environments
2. **User Preference**: Respects individual user preferences
3. **Battery Saving**: Dark mode can save battery on OLED screens
4. **Accessibility**: Helps users with light sensitivity
5. **Modern UX**: Follows current design trends and best practices

## Integration

The dark mode feature is seamlessly integrated with:
- All symptom checker components
- Disease result cards
- Hospital finder cards
- Search interface
- Disclaimer banner
- All shadcn/ui components

## CSS Variables

The application uses CSS custom properties that automatically adapt to dark mode:
- `--background`: Main background color
- `--foreground`: Main text color
- `--primary`: Primary brand color
- `--secondary`: Secondary color
- `--muted`: Muted text and backgrounds
- `--accent`: Accent colors
- `--border`: Border colors
- `--card`: Card backgrounds

## Browser Compatibility

- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

## Future Enhancements

- Add theme transition animations
- Implement auto-switching based on time of day
- Add more theme options (e.g., high contrast mode)
- Sync theme across multiple tabs
- Add keyboard shortcut for theme toggle
